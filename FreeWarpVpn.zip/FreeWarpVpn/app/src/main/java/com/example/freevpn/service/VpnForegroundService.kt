package com.example.freevpn.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.example.freevpn.MainActivity
import com.example.freevpn.data.IpRepository
import com.example.freevpn.data.WarpRepository
import com.example.freevpn.domain.BuildWarpConfigUseCase
import com.example.freevpn.domain.ConnState
import com.example.freevpn.domain.VpnController
import com.example.freevpn.domain.VpnUiState
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class VpnForegroundService : Service() {
    companion object {
        const val ACTION_CONNECT = "com.example.freevpn.CONNECT"
        const val ACTION_DISCONNECT = "com.example.freevpn.DISCONNECT"
        private const val CHANNEL = "vpn"
        private const val NOTIF_ID = 1
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var backend: GoBackend
    private lateinit var warp: WarpRepository
    private val ipRepo = IpRepository()
    private val buildConfig = BuildWarpConfigUseCase()
    private var config: Config? = null
    private var wanted = false
    private var watchdog: Job? = null

    private val tunnel = object : Tunnel {
        override fun getName() = "warp"
        override fun onStateChange(newState: Tunnel.State) {}
    }

    override fun onCreate() {
        super.onCreate()
        backend = GoBackend(applicationContext)
        warp = WarpRepository(applicationContext)
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL, "VPN status", NotificationManager.IMPORTANCE_LOW)
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_DISCONNECT) {
            promote("Disconnecting…")
            scope.launch { disconnect() }
            return START_NOT_STICKY
        }
        promote("Connecting…")
        scope.launch { connect() }
        return START_STICKY
    }

    private suspend fun connect() {
        VpnController.set(VpnUiState(ConnState.CONNECTING))
        try {
            val cfg = buildConfig(warp.getOrRegister())
            config = cfg
            backend.setState(tunnel, Tunnel.State.UP, cfg)
            wanted = true
            val ip = ipRepo.fetch()
            VpnController.set(VpnUiState(ConnState.CONNECTED, ip))
            promote("Connected" + (ip?.let { " · $it" } ?: ""))
            startWatchdog()
        } catch (e: Exception) {
            wanted = false
            VpnController.set(VpnUiState(ConnState.ERROR, error = e.message ?: e.javaClass.simpleName))
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    /** Auto-reconnect: re-raises a dropped tunnel and cycles one that has no connectivity. */
    private fun startWatchdog() {
        watchdog?.cancel()
        watchdog = scope.launch {
            var failures = 0
            while (isActive && wanted) {
                delay(15_000)
                val up = runCatching { backend.getState(tunnel) == Tunnel.State.UP }.getOrDefault(false)
                val ip = if (up) ipRepo.fetch() else null
                if (up && ip != null) {
                    failures = 0
                    if (VpnController.state.value.state != ConnState.CONNECTED) {
                        VpnController.set(VpnUiState(ConnState.CONNECTED, ip))
                        promote("Connected · $ip")
                    }
                    continue
                }
                if (up && ++failures < 2) continue
                failures = 0
                VpnController.set(VpnUiState(ConnState.CONNECTING))
                promote("Reconnecting…")
                runCatching {
                    backend.setState(tunnel, Tunnel.State.DOWN, null)
                    backend.setState(tunnel, Tunnel.State.UP, config)
                }
            }
        }
    }

    private suspend fun disconnect() {
        wanted = false
        watchdog?.cancel()
        runCatching { backend.setState(tunnel, Tunnel.State.DOWN, null) }
        VpnController.set(VpnUiState(ConnState.DISCONNECTED))
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun promote(text: String) {
        val n = notification(text)
        if (Build.VERSION.SDK_INT >= 34) {
            ServiceCompat.startForeground(this, NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun notification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, VpnForegroundService::class.java).setAction(ACTION_DISCONNECT),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("Free WARP VPN")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(0, "Disconnect", stop)
            .build()
    }

    override fun onDestroy() { scope.cancel(); super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}
