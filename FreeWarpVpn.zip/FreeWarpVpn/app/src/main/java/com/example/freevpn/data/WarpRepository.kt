package com.example.freevpn.data

import android.content.Context
import com.wireguard.crypto.KeyPair
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

data class WarpAccount(
    val privateKey: String,
    val peerPublicKey: String,
    val addressV4: String,
    val addressV6: String,
    val endpoint: String
)

/** Registers an anonymous free WARP device (no credentials are bundled in the app). */
class WarpRepository(context: Context) {
    private val prefs = context.getSharedPreferences("warp", Context.MODE_PRIVATE)
    private val http = OkHttpClient()

    suspend fun getOrRegister(): WarpAccount = withContext(Dispatchers.IO) {
        load() ?: register().also { save(it) }
    }

    fun clear() = prefs.edit().clear().apply()

    private fun load(): WarpAccount? {
        val k = prefs.getString("priv", null) ?: return null
        return WarpAccount(
            k,
            prefs.getString("peer", null) ?: return null,
            prefs.getString("v4", null) ?: return null,
            prefs.getString("v6", null) ?: return null,
            prefs.getString("ep", null) ?: return null
        )
    }

    private fun save(a: WarpAccount) = prefs.edit()
        .putString("priv", a.privateKey).putString("peer", a.peerPublicKey)
        .putString("v4", a.addressV4).putString("v6", a.addressV6)
        .putString("ep", a.endpoint).apply()

    private fun register(): WarpAccount {
        val kp = KeyPair()
        val tos = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US)
            .apply { timeZone = TimeZone.getTimeZone("UTC") }.format(Date())
        val body = JSONObject()
            .put("key", kp.publicKey.toBase64())
            .put("install_id", "").put("fcm_token", "")
            .put("tos", tos).put("type", "Android")
            .put("model", "Android").put("locale", "en_US")
            .toString().toRequestBody("application/json; charset=UTF-8".toMediaType())
        val req = Request.Builder()
            .url("https://api.cloudflareclient.com/v0a2158/reg")
            .header("CF-Client-Version", "a-6.3-2158")
            .header("User-Agent", "okhttp/3.12.1")
            .post(body).build()
        http.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) error("WARP registration failed: HTTP ${resp.code}")
            val cfg = JSONObject(resp.body!!.string()).getJSONObject("config")
            val addrs = cfg.getJSONObject("interface").getJSONObject("addresses")
            val peer = cfg.getJSONArray("peers").getJSONObject(0)
            return WarpAccount(
                privateKey = kp.privateKey.toBase64(),
                peerPublicKey = peer.getString("public_key"),
                addressV4 = addrs.getString("v4"),
                addressV6 = addrs.getString("v6"),
                endpoint = "engage.cloudflareclient.com:2408"
            )
        }
    }
}
