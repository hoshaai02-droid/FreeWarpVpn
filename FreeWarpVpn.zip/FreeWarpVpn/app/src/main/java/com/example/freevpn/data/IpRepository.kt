package com.example.freevpn.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

class IpRepository {
    private val http = OkHttpClient.Builder()
        .callTimeout(6, TimeUnit.SECONDS).build()

    /** Returns the public IP as seen from outside, or null if unreachable. */
    suspend fun fetch(): String? = withContext(Dispatchers.IO) {
        runCatching {
            http.newCall(Request.Builder().url("https://api.ipify.org").build())
                .execute().use { if (it.isSuccessful) it.body?.string()?.trim() else null }
        }.getOrNull()
    }
}
