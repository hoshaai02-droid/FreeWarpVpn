package com.example.freevpn.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.freevpn.R
import com.example.freevpn.domain.ConnState

@Composable
fun VpnScreen(vm: VpnViewModel, onToggle: () -> Unit) {
    val ui by vm.ui.collectAsState()
    val (label, color) = when (ui.state) {
        ConnState.CONNECTED -> "Connected" to Color(0xFF2E7D32)
        ConnState.CONNECTING -> "Connecting…" to Color(0xFFF9A825)
        ConnState.ERROR -> "Error" to Color(0xFFC62828)
        ConnState.DISCONNECTED -> "Disconnected" to Color(0xFF757575)
    }
    val active = ui.state == ConnState.CONNECTED || ui.state == ConnState.CONNECTING
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(24.dp))
        Text("Free WARP VPN", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.weight(1f))
        Box(
            Modifier.size(180.dp).clip(CircleShape).background(color)
                .clickable(onClick = onToggle),
            contentAlignment = Alignment.Center
        ) {
            Text(
                if (active) "Disconnect" else "Connect",
                color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold
            )
        }
        Spacer(Modifier.height(20.dp))
        Text(label, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        ui.ip?.let { Text("Public IP: $it") }
        ui.error?.let {
            Spacer(Modifier.height(8.dp))
            Text(it, color = MaterialTheme.colorScheme.error)
            TextButton(onClick = vm::dismissError) { Text("Dismiss") }
        }
        Spacer(Modifier.weight(1f))
        Card(Modifier.fillMaxWidth()) {
            Text(stringResource(R.string.disclaimer), Modifier.padding(12.dp), fontSize = 12.sp)
        }
    }
}
