package com.example.freevpn.domain

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

enum class ConnState { DISCONNECTED, CONNECTING, CONNECTED, ERROR }

data class VpnUiState(
    val state: ConnState = ConnState.DISCONNECTED,
    val ip: String? = null,
    val error: String? = null
)

/** Process-wide state shared between the foreground service and the UI. */
object VpnController {
    private val _state = MutableStateFlow(VpnUiState())
    val state: StateFlow<VpnUiState> = _state
    fun set(s: VpnUiState) { _state.value = s }
}
