package com.example.freevpn.ui

import androidx.lifecycle.ViewModel
import com.example.freevpn.domain.ConnState
import com.example.freevpn.domain.VpnController
import com.example.freevpn.domain.VpnUiState
import kotlinx.coroutines.flow.StateFlow

class VpnViewModel : ViewModel() {
    val ui: StateFlow<VpnUiState> = VpnController.state

    val isActive: Boolean
        get() = ui.value.state.let { it == ConnState.CONNECTED || it == ConnState.CONNECTING }

    fun dismissError() {
        if (ui.value.state == ConnState.ERROR) VpnController.set(VpnUiState())
    }
}
