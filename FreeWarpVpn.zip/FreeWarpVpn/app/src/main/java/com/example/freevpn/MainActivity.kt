package com.example.freevpn

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.core.content.ContextCompat
import com.example.freevpn.service.VpnForegroundService
import com.example.freevpn.ui.VpnScreen
import com.example.freevpn.ui.VpnViewModel
import com.wireguard.android.backend.GoBackend

class MainActivity : ComponentActivity() {
    private val vm: VpnViewModel by viewModels()

    private val vpnPermission =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == RESULT_OK) startVpn()
        }
    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        setContent { MaterialTheme { Surface { VpnScreen(vm, ::onToggle) } } }
    }

    private fun onToggle() {
        if (vm.isActive) {
            startService(
                Intent(this, VpnForegroundService::class.java)
                    .setAction(VpnForegroundService.ACTION_DISCONNECT)
            )
            return
        }
        val prepare = GoBackend.VpnService.prepare(this)
        if (prepare != null) vpnPermission.launch(prepare) else startVpn()
    }

    private fun startVpn() {
        ContextCompat.startForegroundService(
            this,
            Intent(this, VpnForegroundService::class.java)
                .setAction(VpnForegroundService.ACTION_CONNECT)
        )
    }
}
