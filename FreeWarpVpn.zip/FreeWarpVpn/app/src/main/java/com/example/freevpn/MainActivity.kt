package com.example.freevpn

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import java.io.BufferedReader
import java.io.StringReader

// Optional: paste full .conf text between the quotes to hardcode a server.
// If left empty, the config you paste inside the app (Edit button) is used.
private val PRESET_NAMES = listOf("US", "DE", "NL")
private val PRESET_CONFIGS = listOf("", "", "")

sealed class VpnStatus {
    object Idle : VpnStatus()
    data class Connecting(val slot: Int) : VpnStatus()
    data class Connected(val slot: Int) : VpnStatus()
    data class Error(val msg: String) : VpnStatus()
}

/** Saved names/configs (app-private storage). */
class SlotStore(ctx: Context) {
    private val p = ctx.getSharedPreferences("slots", Context.MODE_PRIVATE)
    fun name(i: Int): String = p.getString("name$i", null) ?: PRESET_NAMES[i]
    fun conf(i: Int): String = p.getString("conf$i", null)?.takeIf { it.isNotBlank() } ?: PRESET_CONFIGS[i]
    fun save(i: Int, name: String, conf: String) =
        p.edit().putString("name$i", name).putString("conf$i", conf).apply()
}

/** WireGuard engine + status. */
object VpnEngine {
    val status = MutableStateFlow<VpnStatus>(VpnStatus.Idle)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var backend: GoBackend? = null
    private val tunnel = object : Tunnel {
        override fun getName() = "wg0"
        override fun onStateChange(newState: Tunnel.State) {}
    }

    private fun backend(ctx: Context): GoBackend =
        backend ?: GoBackend(ctx.applicationContext).also { backend = it }

    private fun hasHandshake(b: GoBackend): Boolean = runCatching {
        val s = b.getStatistics(tunnel)
        s.peers().any { (s.peer(it)?.latestHandshakeEpochMillis() ?: 0L) > 0L }
    }.getOrDefault(false)

    fun connect(ctx: Context, slot: Int, confText: String) {
        scope.launch {
            status.value = VpnStatus.Connecting(slot)
            try {
                val cfg = Config.parse(BufferedReader(StringReader(confText.trim())))
                val b = backend(ctx)
                runCatching { b.setState(tunnel, Tunnel.State.DOWN, null) }
                b.setState(tunnel, Tunnel.State.UP, cfg)
                var ok = false
                repeat(15) {
                    if (!ok) {
                        delay(1000)
                        ok = hasHandshake(b)
                    }
                }
                if (ok) {
                    status.value = VpnStatus.Connected(slot)
                } else {
                    runCatching { b.setState(tunnel, Tunnel.State.DOWN, null) }
                    status.value = VpnStatus.Error(
                        "No handshake after 15 s: server unreachable or blocked, or the config keys are invalid."
                    )
                }
            } catch (e: Exception) {
                status.value = VpnStatus.Error(e.message ?: e.javaClass.simpleName)
            }
        }
    }

    fun disconnect(ctx: Context) {
        scope.launch {
            runCatching { backend(ctx).setState(tunnel, Tunnel.State.DOWN, null) }
            status.value = VpnStatus.Idle
        }
    }
}

class MainActivity : ComponentActivity() {
    private val store by lazy { SlotStore(applicationContext) }
    private var pendingSlot = -1

    private val vpnPermission =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (it.resultCode == RESULT_OK && pendingSlot >= 0) startSlot(pendingSlot)
            pendingSlot = -1
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Surface { App() } } }
    }

    private fun startSlot(i: Int) {
        val conf = store.conf(i)
        if (conf.isBlank()) {
            VpnEngine.status.value = VpnStatus.Error("This server has no config yet. Tap Edit and paste a WireGuard .conf.")
        } else {
            VpnEngine.connect(applicationContext, i, conf)
        }
    }

    private fun onTap(i: Int, connectedHere: Boolean) {
        if (connectedHere) {
            VpnEngine.disconnect(applicationContext)
            return
        }
        pendingSlot = i
        val prepare = GoBackend.VpnService.prepare(this)
        if (prepare != null) vpnPermission.launch(prepare) else {
            pendingSlot = -1
            startSlot(i)
        }
    }

    @Composable
    private fun App() {
        val status by VpnEngine.status.collectAsState()
        var version by remember { mutableIntStateOf(0) }
        var editing by remember { mutableStateOf<Int?>(null) }

        val (label, color) = when (val s = status) {
            is VpnStatus.Connected -> "Connected" to Color(0xFF2E7D32)
            is VpnStatus.Connecting -> "Connecting…" to Color(0xFFF9A825)
            is VpnStatus.Error -> "Error" to Color(0xFFC62828)
            VpnStatus.Idle -> "Disconnected" to Color(0xFF757575)
        }

        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)
        ) {
            Spacer(Modifier.height(16.dp))
            Text("WireGuard Servers", fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text("Status: $label", color = color, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            (status as? VpnStatus.Error)?.let {
                Text(it.msg, color = MaterialTheme.colorScheme.error, fontSize = 13.sp)
            }
            Spacer(Modifier.height(12.dp))

            for (i in 0 until 3) {
                val name = remember(version) { store.name(i) }
                val hasConf = remember(version) { store.conf(i).isNotBlank() }
                val connectedHere = (status as? VpnStatus.Connected)?.slot == i
                val connectingHere = (status as? VpnStatus.Connecting)?.slot == i
                val busy = status is VpnStatus.Connecting
                Card(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(name, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                            Text(
                                when {
                                    connectedHere -> "Connected"
                                    connectingHere -> "Connecting…"
                                    hasConf -> "Ready"
                                    else -> "No config. Tap Edit."
                                },
                                fontSize = 13.sp
                            )
                        }
                        TextButton(onClick = { editing = i }, enabled = !busy) { Text("Edit") }
                        Button(onClick = { onTap(i, connectedHere) }, enabled = !busy) {
                            Text(if (connectedHere) "Disconnect" else "Connect")
                        }
                    }
                }
            }

            Spacer(Modifier.height(16.dp))
            Card(Modifier.fillMaxWidth()) {
                Text(
                    "Use only WireGuard configs from providers you trust. Free public servers are not audited and may log your traffic. Use at your own risk.",
                    Modifier.padding(12.dp), fontSize = 12.sp
                )
            }
        }

        editing?.let { i ->
            EditDialog(
                initialName = store.name(i),
                initialConf = store.conf(i),
                onSave = { n, c ->
                    store.save(i, n, c)
                    version++
                    editing = null
                },
                onCancel = { editing = null }
            )
        }
    }

    @Composable
    private fun EditDialog(
        initialName: String,
        initialConf: String,
        onSave: (String, String) -> Unit,
        onCancel: () -> Unit
    ) {
        var name by remember { mutableStateOf(initialName) }
        var conf by remember { mutableStateOf(initialConf) }
        var err by remember { mutableStateOf<String?>(null) }
        AlertDialog(
            onDismissRequest = onCancel,
            title = { Text("Edit server") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    OutlinedTextField(
                        value = name, onValueChange = { name = it },
                        label = { Text("Name (e.g. US)") }, singleLine = true
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = conf, onValueChange = { conf = it },
                        label = { Text("Paste WireGuard .conf") }, minLines = 8
                    )
                    err?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 12.sp) }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    try {
                        Config.parse(BufferedReader(StringReader(conf.trim())))
                        onSave(name.ifBlank { initialName }, conf.trim())
                    } catch (e: Exception) {
                        err = e.message ?: "Invalid config"
                    }
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = onCancel) { Text("Cancel") } }
        )
    }
}
