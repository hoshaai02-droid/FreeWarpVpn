package com.example.freevpn.domain

import com.example.freevpn.data.WarpAccount
import com.wireguard.config.Config
import java.io.BufferedReader
import java.io.StringReader

/**
 * Full-tunnel config. AllowedIPs covers IPv4 and IPv6, and DNS points at Cloudflare
 * resolvers inside the tunnel, so neither traffic nor DNS bypasses the VPN.
 */
class BuildWarpConfigUseCase {
    operator fun invoke(a: WarpAccount): Config {
        val text = """
            [Interface]
            PrivateKey = ${a.privateKey}
            Address = ${a.addressV4}/32, ${a.addressV6}/128
            DNS = 1.1.1.1, 1.0.0.1, 2606:4700:4700::1111, 2606:4700:4700::1001
            MTU = 1280

            [Peer]
            PublicKey = ${a.peerPublicKey}
            AllowedIPs = 0.0.0.0/0, ::/0
            Endpoint = ${a.endpoint}
            PersistentKeepalive = 25
        """.trimIndent()
        return Config.parse(BufferedReader(StringReader(text)))
    }
}
