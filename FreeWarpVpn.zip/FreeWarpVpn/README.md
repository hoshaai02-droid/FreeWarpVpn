# Free WARP VPN (Android, Kotlin + Compose)

A standalone VPN client that needs no server of your own. It registers an anonymous
free **Cloudflare WARP** device and tunnels all traffic with the official
`com.wireguard.android:tunnel` library.

## Build
1. Open the folder in Android Studio (Hedgehog or newer, JDK 17). It generates the Gradle wrapper and syncs.
2. `Build > Build APK(s)` for a debug APK, or `Build > Generate Signed Bundle / APK` for release.
3. Install on a device (API 26+). Android shows the system VPN consent dialog on first connect.

> This project was written without being compiled. Expect to fix small API or version mismatches on first sync.

## How it works
- `WarpRepository` generates a WireGuard keypair on-device and POSTs the public key to
  Cloudflare's client registration endpoint. The returned peer key and addresses are stored
  in app-private SharedPreferences. No API keys are bundled.
- `BuildWarpConfigUseCase` builds a full-tunnel config: `0.0.0.0/0` and `::/0`, DNS set to
  Cloudflare resolvers inside the tunnel (no DNS or IPv6 leak by design), MTU 1280.
- `VpnForegroundService` brings the tunnel up through `GoBackend`, shows a persistent
  notification with a Disconnect action, and runs a watchdog every 15 s. If the tunnel is
  down or has no connectivity (public-IP check fails twice) it cycles the tunnel.
- The UI shows state and public IP (via `api.ipify.org`, fetched through the tunnel).
- The `BIND_VPN_SERVICE` service (`GoBackend$VpnService`) is declared by the WireGuard library's manifest.

## Differences from the original spec
- **No VPN Gate.** VPN Gate serves OpenVPN configs only, and WireGuard cannot use them.
  Adding it means vendoring ics-openvpn (GPLv2, native code).
- **No server list or ping selection.** WARP assigns the nearest Cloudflare datacenter
  automatically; there is nothing to choose. Connect is one tap.

## Limitations
- WARP is not an anonymity tool. Cloudflare sees your connection metadata.
- The registration endpoint and client headers are unofficial and may change or be rate-limited.
- Free tier: no uptime or speed guarantee. The private key is stored unencrypted in app-private
  storage (use EncryptedSharedPreferences to harden).
- "Block connections without VPN" (lockdown) is a user setting in Android's system VPN settings.

## Google Play
VPN must be the core functionality; complete the VpnService declaration in Play Console,
add a privacy policy, and keep the in-app disclaimer visible. Review Cloudflare's WARP
terms before distributing an app that registers accounts on users' behalf.
